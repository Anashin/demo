

# Frontend challenge - Todo app

##Presentation

Making my first todo app from scratch with a bit of challenge for my frontend skills .


##Design from Frontend Mentor
 
![Design preview for the Todo app coding challenge](./design/desktop-preview.jpg) 

## View 

https://miniyass.github.io/TodoList-Challenge/



